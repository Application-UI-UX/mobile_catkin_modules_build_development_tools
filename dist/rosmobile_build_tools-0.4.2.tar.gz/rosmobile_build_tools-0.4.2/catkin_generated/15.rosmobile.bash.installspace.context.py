# generated from catkin/cmake/template/env-hook.context.py.in
DEVELSPACE = False
INSTALLSPACE = True

CATKIN_DEVEL_PREFIX = '/home/ronaldsonbellande-hplaptop/Desktop/User_Interface_Experience/rosmobile_build_tools/devel'

CATKIN_GLOBAL_BIN_DESTINATION = 'bin'
CATKIN_GLOBAL_ETC_DESTINATION = 'etc'
CATKIN_GLOBAL_INCLUDE_DESTINATION = 'include'
CATKIN_GLOBAL_LIB_DESTINATION = 'lib'
CATKIN_GLOBAL_LIBEXEC_DESTINATION = 'lib'
CATKIN_GLOBAL_PYTHON_DESTINATION = 'lib/python3/dist-packages'
CATKIN_GLOBAL_SHARE_DESTINATION = 'share'

CATKIN_PACKAGE_BIN_DESTINATION = ''
CATKIN_PACKAGE_ETC_DESTINATION = ''
CATKIN_PACKAGE_INCLUDE_DESTINATION = ''
CATKIN_PACKAGE_LIB_DESTINATION = ''
CATKIN_PACKAGE_LIBEXEC_DESTINATION = ''
CATKIN_PACKAGE_PYTHON_DESTINATION = ''
CATKIN_PACKAGE_SHARE_DESTINATION = ''

CMAKE_BINARY_DIR = '/home/ronaldsonbellande-hplaptop/Desktop/User_Interface_Experience/rosmobile_build_tools'
CMAKE_CURRENT_BINARY_DIR = '/home/ronaldsonbellande-hplaptop/Desktop/User_Interface_Experience/rosmobile_build_tools'
CMAKE_CURRENT_SOURCE_DIR = '/home/ronaldsonbellande-hplaptop/Desktop/User_Interface_Experience/rosmobile_build_tools'
CMAKE_INSTALL_PREFIX = '/usr/local'
CMAKE_SOURCE_DIR = '/home/ronaldsonbellande-hplaptop/Desktop/User_Interface_Experience/rosmobile_build_tools'

PROJECT_NAME = 'rosmobile_build_tools'
PROJECT_BINARY_DIR = '/home/ronaldsonbellande-hplaptop/Desktop/User_Interface_Experience/rosmobile_build_tools'
PROJECT_SOURCE_DIR = '/home/ronaldsonbellande-hplaptop/Desktop/User_Interface_Experience/rosmobile_build_tools'

PYTHON_EXECUTABLE = '/usr/bin/python3'
