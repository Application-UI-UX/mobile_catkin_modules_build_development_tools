#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables
export ROS_MAVEN_DEPLOYMENT_REPOSITORY='/home/ronaldsonbellande-hplaptop/Desktop/User_Interface_Experience/rosmobile_build_tools/devel/share/maven'
export ROS_MAVEN_PATH='/home/ronaldsonbellande-hplaptop/Desktop/User_Interface_Experience/rosmobile_build_tools/devel/share/maven:/opt/ros/main/share/maven'
export ROS_MAVEN_REPOSITORY='Nothing to see here - please provide one of the valid command switches.'

# modified environment variables
export CMAKE_PREFIX_PATH="/home/ronaldsonbellande-hplaptop/Desktop/User_Interface_Experience/rosmobile_build_tools/devel:$CMAKE_PREFIX_PATH"
export LD_LIBRARY_PATH='/home/ronaldsonbellande-hplaptop/Desktop/User_Interface_Experience/rosmobile_build_tools/devel/lib:/opt/ros/main/lib:/usr/local/cuda/lib64:/usr/local/cuda-11.0/lib64:/usr/local/cuda/lib64:/usr/local/cuda-11.0/lib64'
export PATH='/home/ronaldsonbellande-hplaptop/Desktop/User_Interface_Experience/rosmobile_build_tools/devel/bin:/opt/ros/main/bin:/home/ronaldsonbellande-hplaptop/.local/bin:/home/ronaldsonbellande-hplaptop/.sdkman/candidates/gradle/current/bin:/home/ronaldsonbellande-hplaptop/.local/bin:/opt/gradle/gradle-7.2/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin'
export PKG_CONFIG_PATH="/home/ronaldsonbellande-hplaptop/Desktop/User_Interface_Experience/rosmobile_build_tools/devel/lib/pkgconfig:$PKG_CONFIG_PATH"
export PYTHONPATH="/home/ronaldsonbellande-hplaptop/Desktop/User_Interface_Experience/rosmobile_build_tools/devel/lib/python3/dist-packages:$PYTHONPATH"
export ROS_PACKAGE_PATH="/home/ronaldsonbellande-hplaptop/Desktop/User_Interface_Experience/rosmobile_build_tools:$ROS_PACKAGE_PATH"