This is not installed, but it gets used to generate the gradle wrapper for a project.

It is currently the gradle wrapper supporting gradle 7.5.1.
